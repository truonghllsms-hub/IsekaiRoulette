# Prompt Gemini: kịch bản đời người — ORC (orc)

Tỉ lệ đầu thai **2%** · nhóm **ma vật / dị tộc** · hệ số nội dung **×1**
Khoảng **105** mục nội dung, chia thành **10 phần**.

**Cách dùng**
1. Mở một cuộc trò chuyện mới với Gemini. Dán **KHỐI CHUNG** trước.
2. Dán lần lượt từng **PHẦN**, mỗi lần một phần. Đọc xong phần này mới gửi phần sau.
   Nếu Gemini dừng giữa chừng, gõ "viết tiếp".
3. Kết quả là **kịch bản bằng chữ** để bạn đọc và sửa. Chưa cần JSON.
4. Duyệt xong, gửi lại toàn bộ cho Claude để chuyển thành dữ liệu game.

> Tộc này dùng các hệ thống riêng của ma vật (vai trò, thứ bậc, tiến hóa...). Claude sẽ nối vào engine sau khi bạn duyệt kịch bản.

---

## KHỐI CHUNG (dán đầu tiên)

```
Bạn là biên kịch cho một web game chữ tiếng Việt, văn phong isekai manga/light novel dịch, tên "Luân Hồi Dị Giới": người chơi đầu thai vào thế giới
giả tưởng Aethelgard và sống trọn một kiếp, từ lúc sinh đến lúc chết, qua từng năm.
Lần này bạn viết kịch bản cho chủng tộc ORC (chiến binh da xanh nanh dài, trọng sức mạnh và danh dự). Chỉ 2% linh hồn được đầu thai vào tộc này.

=== ORC LÀ AI ===
Thân hình to lớn vượt trội so với con người, cơ bắp cuồn cuộn với làn da xanh thẫm, xám hoặc đỏ rực cùng cặp nanh lòi ra đầy đe dọa. Orc bạo lực, cục cằn nhưng lại rất thẳng thắn. Chúng cực kỳ trọng danh dự chiến binh, tuyệt đối khinh bỉ pháp thuật, những trò đánh lén và sự hèn nhát.
Xã hội: Sống theo các bộ lạc du mục lớn hoặc chiếm đóng các phế tích bỏ hoang ngoài Rừng Tân Thủ. Xã hội Orc vận hành theo nguyên tắc vàng: Kẻ mạnh nhất có tất cả. Quyền lực tuyệt đối thuộc về Tù Trưởng (Warchief). Bất cứ ai cũng có quyền thách đấu Tù Trưởng để giành ngôi, nhưng cái giá của sự thất bại thường là cái chết hoặc bị lưu đày vĩnh viễn.
Không khí riêng: Thô bạo, thẳng thắn, trọng danh dự chiến binh. Tiếng trống và tiếng gầm.
Chủ đề nên khai thác: Danh dự, khinh pháp thuật, thách đấu Tù trưởng, bị lưu đày, liên minh hay chiến tranh với loài người.
Cách ra đời: Sinh ra trong bộ lạc du mục. Cha mẹ rõ ràng; cha thường là chiến binh và có thể chết trận sớm. Con yếu bị coi là nỗi nhục.

=== GIAI ĐOẠN ĐỜI ===
tuổi thọ 40–45 năm
Orc non nớt 0–4 · Tân binh bộ lạc 4–10 · Chiến binh máu nóng 10–16 · Huyết Kỵ Sĩ 16–26 · Tướng lĩnh chiến trường 26–36 · Tù trưởng già cỗi 36+
Những giai đoạn trẻ và sung sức là lúc nhiều biến cố nhất: viết nhiều cho các giai đoạn này.

=== CÁCH GAME VẬN HÀNH (để bạn viết cho khớp) ===
- Mỗi năm người chơi chọn một VIỆC CHÍNH: Đánh nhau (tuổi nhỏ) · Học lời tổ tiên (từ thầy cúng) · Khổ luyện · Phục dịch bộ lạc · Chinh phạt · Thách đấu và tranh quyền · Uống rượu nghỉ ngơi.
- 4 chỉ số: Sức mạnh, Trí tuệ, Nhanh nhẹn, May mắn (thường 1–15). 3 thanh: Sức khỏe, Hạnh phúc, Tài sản (với ma vật là chiến lợi phẩm, của cải). Thêm Danh vọng (tiếng tăm trong đồng loại).
- VAI TRÒ (thay cho nghề): mỗi vai trò 5 bậc, thăng bậc bằng thử thách dựa vào chỉ số chính.
- THỨ BẬC trong Bộ lạc chiến binh: 7 bậc từ Nanh non lên Tù trưởng Chiến (Warchief) (bạn đặt tên).
- CUỘC CHINH PHẠT (thay cho nhiệm vụ của mạo hiểm giả): 1–4 CẢNH nối tiếp, mỗi cảnh 2–3 lựa chọn.
- ĐỘI CHIẾN (thay cho tổ đội): tối đa 3 kẻ đồng hành có tên và tính cách.
- GIÀNH BẠN ĐỜI BẰNG CHIẾN CÔNG (thay cho hôn nhân) và con cháu.
- TIẾN HÓA: High Orc · Orc Warlord.
- DẤU ẤN: lựa chọn để lại dấu ấn; nhiều năm sau, sự kiện khác chỉ xảy ra nếu có dấu ấn đó.
- Game đã có sẵn 48 sự kiện cũ cho tộc này (đời thường, ngẫu nhiên). Lần này bạn viết LỚP MỚI gắn với
  việc chính, vai trò, cuộc chinh phạt, đội chiến, gia đình. Tránh lặp lại những ý quá quen.

=== THẾ GIỚI AETHELGARD ===
Lịch Kỷ Nguyên Khai Hoang. Tiền: Đồng Cẩm Thạch → Tinh Bạc → Huyết Kim → Lõi Mana.
Vùng đất: Đồng Bằng Thánh Quang (thủ đô Sanctus, Học viện Ma pháp Tháp Ngà; Con người, Dwarf),
Thảo Nguyên Gió Hú (Beastman, Con người, Orc), Đại Ngàn Lục Bảo (Elf, Cây Thế Giới Yggdrasil),
Dãy Núi Răng Cưa (Dwarf, Kobold; Lò Rèn Vĩnh Cửu), Đầm Lầy Tử Khí (Lizardman, Slime, Goblin),
Vực Thẳm Phân Tầng (Ma tộc, Imp, Vampire, Ghoul, Troll; Cửa Ngục Than Khóc), Đảo Tro Tàn (Rồng, Minotaur; Đỉnh Hỏa Ngục).
Tôn giáo: Giáo hội Thánh Quang (Nữ thần Lumina, căm ghét ma vật), Tự Nhiên Giáo (trung lập),
Hắc Nguyệt Hội (tà giáo thờ Vực Thẳm Cổ Thần, hiến tế).
Tổ chức: Guild Bình Minh (mạo hiểm giả), Học viện Ma pháp Tháp Ngà, Thánh Kỵ Sĩ Đoàn, Quân đoàn Ma Vương (của Ma Vương),
Thương hội Sói Bạc, Guild Sát thủ Umbra, Đấu trường Huyết Sa, Đội Ranger Đại Ngàn.
4 thời đại: Thời Bình · Chiến Tranh Tuyến Đầu · Kỷ Nguyên Tăm Tối (dịch bệnh, đói) · Ma Vương Giáng Thế.

=== PHONG CÁCH TÊN GỌI: KIỂU MANGA / LIGHT NOVEL DỊCH (BẮT BUỘC) ===
- Tên chủng tộc GIỮ NGUYÊN tiếng Anh: Human, Beastman, Dwarf, Elf, Demon, Goblin, Slime, Kobold, Lizardman,
  Vampire, Imp, Orc, Minotaur, Troll, Ghoul, Dragon, High Demon. Beastman ghi kèm dạng thú: "Beastman tộc Mèo".
  KHÔNG dịch thuần Việt kiểu "Yêu tinh xanh", "Người lùn", "Tiên tộc", "Chằn tinh", "Khổng lồ ngốc".
  Khi một tộc xuất hiện lần đầu trong đoạn mở đầu, kèm giải thích ngắn trong ngoặc, ví dụ:
  "Bạn là Gruum, thuộc chủng tộc Goblin (tiểu yêu da xanh sống theo bầy, yếu ớt nhưng ranh mãnh)."
- Nghề, chức vụ, cấp bậc, danh hiệu theo lối truyện isekai dịch:
  Hán Việt đã thành chuẩn: Kiếm Thánh, Hiền Giả, Dũng Giả, Ma Vương, Thánh Nữ, Đại Ma pháp sư, Mạo hiểm giả hạng S;
  hoặc tên class tiếng Anh: Assassin, Priest, Ranger, Berserker, Tamer, Necromancer, Dark Knight.
  Biến thể và tiến hóa của ma vật luôn bằng tiếng Anh: Hobgoblin, Goblin Lord, High Orc, Slime King, Ancient Dragon, Lich.
- Hệ thống gọi như manga: Guild, hạng F→S, Skill, tiến hóa, triệu hồi, Dungeon (hầm ngục).
- Tên tổ chức: Guild Bình Minh (Hội Mạo hiểm giả), Học viện Ma pháp Tháp Ngà, Thánh Kỵ Sĩ Đoàn, Quân đoàn Ma Vương,
  Thương hội Sói Bạc, Guild Sát thủ Umbra, Đấu trường Huyết Sa, Đội Ranger Đại Ngàn.
- Văn kể vẫn là tiếng Việt Epic RPG, ngôi thứ hai. Chỉ tên riêng và thuật ngữ mang màu manga.

=== GIỌNG VĂN: EPIC RPG ===
Sử thi, trang trọng, tự sự cổ điển, ngôi thứ hai ("bạn"). Mỗi đoạn 1–2 câu. Câu sau là một hình ảnh
hoặc chi tiết định mệnh. Được phép hài hước khô khan hoặc u tối khi hợp cảnh.
Ví dụ đạt: "Một kỵ sĩ quý tộc ném găng xuống chân bạn giữa quảng trường, chỉ vì bạn không cúi chào."
Ví dụ đạt: "{ally} quỳ bên bạn suốt đêm, đôi tay phát sáng ánh thánh quang. Sáng hôm sau, bạn mở mắt."
KHÔNG dùng tên, câu chữ hay tình huống của game, truyện, phim có thật.
Riêng tộc này: Thô bạo, thẳng thắn, trọng danh dự chiến binh. Tiếng trống và tiếng gầm.

=== LỰA CHỌN PHẢI CÓ Ý NGHĨA ===
- Mỗi lựa chọn nên dựa vào MỘT chỉ số khác nhau, để người mạnh, người khôn, người nhanh, người may mắn
  đều có lối đi riêng.
- Có thể thêm một lựa chọn BỊ KHÓA nếu thiếu chỉ số hoặc dấu ấn (ví dụ "chỉ mở khi Trí tuệ từ 7").
  Người chơi vẫn thấy nó và biết mình thiếu gì.
- Luôn có ít nhất một lựa chọn an toàn hoặc hèn nhát nhưng có cái giá riêng.
- Độ khó dùng 4 mức: DỄ, VỪA, KHÓ, RẤT KHÓ.
- Hệ quả ghi rõ con số: Sức mạnh +1, Tài sản +10, Sức khỏe −20, Danh vọng +3,
  Thân thiết với {ally} +10, dấu ấn "ten_dau_an". Nếu chết thì ghi CHẾT và viết câu mô tả cái chết.
- Năm yên ả được game tự gộp lại. Vì vậy mỗi sự kiện phải ĐÁNG KỂ: có biến cố, có lựa chọn, hoặc một chi
  tiết khó quên. KHÔNG viết kiểu "một năm bình thường trôi qua".

=== TÊN GỌI TRONG CÂU CHỮ ===
{name} tên nhân vật · {father} cha · {mother} mẹ · {maker} kẻ tạo ra/chủ nhân (cho tộc không có cha mẹ)
{ally} một đồng đội · {spouse} bạn đời · {child} một đứa con.

=== MẪU TRÌNH BÀY (dùng đúng mẫu này cho mọi sự kiện) ===

### [MÃ] Tên ngắn
- **Khi nào:** giai đoạn · việc chính · nghề và bậc (nếu có) · điều kiện khác (chỉ số, dấu ấn, có đồng đội, cha/mẹ còn sống...)
- **Tình huống:** 1–2 câu.
- **A. "Nhãn lựa chọn"** — dựa vào [chỉ số], [độ khó]
  - Thành công: 1–2 câu. → hệ quả
  - Thất bại: 1–2 câu. → hệ quả
- **B. "Nhãn lựa chọn"** — (không tung xúc xắc) 1–2 câu. → hệ quả
- **C. "Nhãn lựa chọn"** — KHÓA nếu Trí tuệ dưới 7 — 1–2 câu. → hệ quả
- **Khoảnh khắc:** (tùy chọn) một dòng ngắn ghi vào tổng kết cuộc đời.

Sự kiện KHÔNG có lựa chọn thì chỉ cần: Khi nào, Tình huống, Hệ quả.

QUY ƯỚC BẮT BUỘC (để game đọc đúng):
- Dòng khóa luôn viết dạng điều kiện CẦN CÓ: "KHÓA: cần Trí tuệ 6", "KHÓA: cần dấu ấn "x" hoặc Trí tuệ 7".
  Không viết "KHÓA nếu ... từ ..." (dễ hiểu ngược).
- Sự kiện có lựa chọn phải có ÍT NHẤT 2 lựa chọn. Lựa chọn liều mạng luôn đi kèm một lựa chọn an toàn hoặc hèn nhát.
- Chỉ tung xúc xắc bằng: Sức mạnh, Trí tuệ, Nhanh nhẹn, May mắn hoặc Sức khỏe.
- Tài sản và Danh vọng tính trên thang 0–100: thưởng thường +5..+30, thưởng huyền thoại tối đa +100.
- Hệ quả đặc biệt dùng đúng chữ: "thu nhận {ally}", "mất {ally}", "có {spouse}", "có {child}", "mất {child}",
  "giáng chức về Bậc 1", "thăng bậc <tên bậc>", "TIẾN HÓA THÀNH <tên>", "CHẾT (lý do ngắn)".
- Mỗi kết quả trong một CẢNH của nhiệm vụ/cướp phá kết thúc bằng đúng một trong: (THẮNG NGAY ...), (THẤT BẠI NGAY ...),
  (Chuyển sang CẢNH n ...), (CHẾT, lý do). Không ghi gì nghĩa là đi tiếp sang cảnh kế.
MÃ viết thường, không dấu, bắt đầu bằng mã tộc, ví dụ orc_job_duel, orc_quest_ruins_2.

Hãy trả lời "Đã hiểu" và chờ tôi gửi từng phần.
```

---

## PHẦN 1 — Xuất thân và cha mẹ

```
PHẦN 1: Xuất thân và cha mẹ

Viết lại xuất thân, lần này kèm đầy đủ thông tin CHA MẸ.
Cách ra đời của tộc này: Sinh ra trong bộ lạc du mục. Cha mẹ rõ ràng; cha thường là chiến binh và có thể chết trận sớm. Con yếu bị coi là nỗi nhục.

a) 5 xuất thân ĐÃ CÓ bên dưới: giữ tên và ý chính, bổ sung cha mẹ, anh chị em, gia cảnh.
   - Sinh ra trong khói lửa (dấu ấn: warborn)
   - Dòng máu Tù trưởng (dấu ấn: royal_blood)
   - Nô lệ giác đấu (dấu ấn: gladiator)
   - Đứa con của Tà Thần (dấu ấn: blessed_orc)
   - Mầm Mống Tàn Lụi (dấu ấn: orphan_orc)
b) Viết thêm 1 xuất thân MỚI.

Mỗi xuất thân viết theo mẫu:

### [MÃ] Tên xuất thân — tỉ lệ gặp (phần trăm, cộng các xuất thân lại khoảng 100)
- **Đoạn mở đầu:** 2–3 câu kể lúc bạn ra đời.
- **Cha:** tên · tộc · nghề hoặc vai trò · tính cách · tình trạng lúc bạn ra đời (còn sống / đã mất / bỏ đi / không rõ là ai)
- **Mẹ:** như trên
- **Anh chị em:** số lượng và một chi tiết đáng nhớ (hoặc "không có")
- **Gia cảnh:** 1 câu (giàu nghèo, được yêu thương hay bị ruồng bỏ)
- **Ảnh hưởng:** chỉ số cộng/trừ, Tài sản, dấu ấn

c) 4 SỰ KIỆN VỀ CHA MẸ trải khắp cuộc đời, theo mẫu sự kiện. Ví dụ: {father} dạy bạn điều đầu tiên,
   {mother} lâm bệnh, cha mẹ phản đối vai trò hay người bạn chọn, bạn gặp lại người cha đã bỏ đi,
   cha mẹ qua đời và bạn thừa kế (hoặc gánh nợ), bạn trở thành người chăm sóc cha mẹ già.
   Ghi rõ điều kiện (ví dụ "chỉ khi cha còn sống", "chỉ khi xuất thân mồ côi").
```

---

## PHẦN 2 — Vai trò

```
PHẦN 2: Vai trò

Tộc này có 5 vai trò. Gợi ý (được đổi tên, gộp, thay hoặc thêm nếu bạn có ý hay hơn, miễn đủ 5):
Orc Berserker (Sức mạnh) · Orc Hunter (Nhanh nhẹn) · Orc Shaman (Trí tuệ, bị coi thường vì Orc khinh pháp thuật) · Orc Smith (Sức mạnh) · Wolf Tamer chăn sói chiến (không cần gì)

Trước tiên, liệt kê đủ 5 vai trò bạn chọn (tên + chỉ số chính + 1 câu mô tả), đánh số 1 → 5.
Sau đó viết chi tiết vai trò số 1 → 5.

Với MỖI vai trò, viết:
1. Điều kiện (chỉ số tối thiểu) và lối vào phụ theo xuất thân.
2. Tên 5 bậc, từ thấp đến cao.
3. Câu mở đầu khi nhận vai trò.
4. 4 thử thách thăng bậc, độ khó tăng dần.
5. 3 câu "năm yên ả".
6. 4 SỰ KIỆN theo mẫu, ít nhất 3 có lựa chọn. Ít nhất 1 sự kiện có thể khiến bị giáng chức, bị đuổi hoặc mất mạng.
```

---

## PHẦN 3 — Thứ bậc: Bộ lạc chiến binh

```
PHẦN 3: Thứ bậc: Bộ lạc chiến binh

Đặt tên 7 bậc của Bộ lạc chiến binh (7 bậc từ Nanh non lên Tù trưởng Chiến (Warchief) (bạn đặt tên)). Mỗi bậc viết 1 câu khi được thăng lên bậc đó.
Viết thêm 1 sự kiện đặc biệt để leo lên bậc cao nhất (thách đấu, lật đổ, được thừa nhận...), có 3 lựa chọn dựa vào 3 chỉ số khác nhau.
```

---

## PHẦN 4 — Sự kiện theo việc chính (đợt 1/2)

```
PHẦN 4: Sự kiện theo việc chính (đợt 1/2)

Viết sự kiện theo VIỆC CHÍNH của năm. Mỗi việc chính dưới đây: 3 sự kiện (ít nhất một nửa có lựa chọn),
trải đều các giai đoạn đời mà việc đó có thể diễn ra, cộng thêm 3 câu "năm yên ả" cho mỗi giai đoạn phù hợp.
- Đánh nhau
- Học lời tổ tiên
- Khổ luyện
- Phục dịch bộ lạc
- Chinh phạt
```

---

## PHẦN 5 — Sự kiện theo việc chính (đợt 2/2)

```
PHẦN 5: Sự kiện theo việc chính (đợt 2/2)

Viết sự kiện theo VIỆC CHÍNH của năm. Mỗi việc chính dưới đây: 3 sự kiện (ít nhất một nửa có lựa chọn),
trải đều các giai đoạn đời mà việc đó có thể diễn ra, cộng thêm 3 câu "năm yên ả" cho mỗi giai đoạn phù hợp.
- Thách đấu và tranh quyền
- Uống rượu nghỉ ngơi
```

---

## PHẦN 6 — Các cuộc chinh phạt nhỏ

```
PHẦN 6: Các cuộc chinh phạt nhỏ

Cuộc chinh phạt của Bộ lạc chiến binh. Mỗi cái gồm: tên, bậc tối thiểu,
một gợi ý ngắn hiện trên bảng (ví dụ "Vừa. Hay có bẫy"), đoạn mở đầu, các CẢNH (mỗi cảnh viết theo mẫu sự kiện),
đoạn kết khi thành công, phần thưởng (Tài sản, Danh vọng, điểm thăng bậc) và khoảnh khắc.
Ghi rõ lựa chọn nào khiến THẤT BẠI NGAY, THẮNG NGAY, hoặc gây CHẾT.

Viết 5 cuộc chinh phạt NHỎ lặp lại được, 1–2 cảnh, rải đều từ bậc thấp đến bậc giữa.
```

---

## PHẦN 7 — Cuộc chinh phạt cốt truyện

```
PHẦN 7: Cuộc chinh phạt cốt truyện

Tộc này có 4 cuộc chinh phạt CỐT TRUYỆN chỉ làm một lần, mỗi cái 3–5 cảnh, độ khó tăng dần từ bậc thấp đến bậc cao nhất.
Cái cuối cùng phải mang tầm vóc huyền thoại. Ít nhất 2 cái để lại DẤU ẤN mà phần "Chuỗi hệ quả" sẽ dùng lại.
Trước tiên liệt kê tên + bậc của cả 4 cái. Viết chi tiết số 1 → 4, cùng mẫu như phần cuộc chinh phạt nhỏ.

Viết thêm 2 cuộc chinh phạt chỉ xuất hiện trong một thời đại cụ thể (Chiến Tranh Tuyến Đầu, Kỷ Nguyên Tăm Tối hoặc Ma Vương Giáng Thế).
```

---

## PHẦN 8 — Đội chiến

```
PHẦN 8: Đội chiến

Sự kiện về đội chiến. Gọi đồng đội là {ally}. Mỗi đồng đội có một tính cách:
Dũng cảm, Trung thành, Tham lam, Nhút nhát, Vui tính, Lạnh lùng.
a) Với mỗi tính cách: 1 sự kiện riêng, tính cách phải thể hiện rõ.
b) 4 sự kiện chung: cãi vã, cứu nhau, chia chiến lợi phẩm, một người muốn rời đi, bí mật quá khứ bị lộ...
c) 3 câu khi đồng đội CHẾT, 3 câu khi BỊ THƯƠNG, 3 câu khi BỎ ĐI hoặc PHẢN BỘI.
```

---

## PHẦN 9 — Giành bạn đời bằng chiến công, tiến hóa, tuổi già

```
PHẦN 9: Giành bạn đời bằng chiến công, tiến hóa, tuổi già

a) 3 cảnh về giành bạn đời bằng chiến công, mỗi cảnh có kết quả thành công và thất bại.
b) 5 sự kiện về con cháu {child}.
c) TIẾN HÓA, 2 nhánh: High Orc, Orc Warlord. Mỗi nhánh viết: điều kiện (chỉ số, dấu ấn, tuổi),
   1 sự kiện báo hiệu, 1 sự kiện tiến hóa có lựa chọn (thành công thì tăng mạnh chỉ số và đổi hình dạng,
   thất bại có thể chết), và 2 sự kiện chỉ xảy ra SAU khi đã tiến hóa.
d) 4 sự kiện cuối đời.
```

---

## PHẦN 10 — Chuỗi hệ quả

```
PHẦN 10: Chuỗi hệ quả

Tộc này có 4 CHUỖI HỆ QUẢ, mỗi chuỗi 2–3 sự kiện cách nhau nhiều năm.
- Sự kiện đầu để lại một DẤU ẤN. Sự kiện sau CHỈ xảy ra nếu có dấu ấn đó, và kết quả khác nhau tùy lựa chọn năm xưa.
- Ít nhất 2 chuỗi dùng dấu ấn từ cuộc chinh phạt cốt truyện; ít nhất 1 chuỗi liên quan đến cha mẹ.
- Ghi tên dấu ấn rõ ràng, ví dụ dấu ấn "tha_ten_trom".
Viết chuỗi số 1 → 4.
```
