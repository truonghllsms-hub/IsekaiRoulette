# Prompt Gemini: kịch bản đời người — ELF (elf)

Tỉ lệ đầu thai **7%** · nhóm **văn minh (đủ nghề, Hội, tổ đội)** · hệ số nội dung **×1**
Khoảng **126** mục nội dung, chia thành **11 phần**.

**Cách dùng**
1. Mở một cuộc trò chuyện mới với Gemini. Dán **KHỐI CHUNG** trước.
2. Dán lần lượt từng **PHẦN**, mỗi lần một phần. Đọc xong phần này mới gửi phần sau.
   Nếu Gemini dừng giữa chừng, gõ "viết tiếp".
3. Kết quả là **kịch bản bằng chữ** để bạn đọc và sửa. Chưa cần JSON.
4. Duyệt xong, gửi lại toàn bộ cho Claude để chuyển thành dữ liệu game.

---

## KHỐI CHUNG (dán đầu tiên)

```
Bạn là biên kịch cho một web game chữ tiếng Việt, văn phong isekai manga/light novel dịch, tên "Luân Hồi Dị Giới": người chơi đầu thai vào thế giới
giả tưởng Aethelgard và sống trọn một kiếp, từ lúc sinh đến lúc chết, qua từng năm.
Lần này bạn viết kịch bản cho chủng tộc ELF (tộc tai nhọn của rừng thiêng, sống cả nghìn năm). Chỉ 7% linh hồn được đầu thai vào tộc này.

=== ELF LÀ AI ===
Elf mang trong mình huyết mạch tinh thuần từ thuở khai thiên, thọ mệnh dài đằng đẵng sánh ngang cội nguồn núi non. Bánh xe định mệnh đưa bạn đến Đại Ngàn Lục Bảo, nơi những đứa con của Yggdrasil gánh vác sứ mệnh bảo vệ sự cân bằng vĩnh hằng.

Không khí riêng: Thanh tao, u hoài, nhìn thế gian qua hàng thế kỷ. Bi kịch nằm ở chỗ những người bạn phàm trần lần lượt già đi và chết.
Chủ đề nên khai thác: Thời gian dài đằng đẵng (một sự kiện có thể kéo dài 50 năm), chứng kiến bạn bè phàm trần chết, bảo vệ Đại Ngàn khỏi con người khai thác, kiêu ngạo chủng tộc.
Cách ra đời: Sinh ra từ cha mẹ Elf. Elf sinh con rất hiếm; một đứa trẻ là sự kiện của cả cộng đồng. Cha mẹ sống hàng nghìn năm nên có thể đồng hành cả đời bạn, hoặc rời đi vì lý do riêng. Con lai với Con người (Half-Elf) bị cả hai bên xa lánh.

=== GIAI ĐOẠN ĐỜI ===
tuổi thọ 1.000–2.000 năm
Sơ sinh 0–60 · Thơ ấu 60–225 · Thiếu niên 225–375 · Trưởng thành 375–825 · Trung niên 825–1.200 · Tuổi già 1.200+
Những giai đoạn trẻ và sung sức là lúc nhiều biến cố nhất: viết nhiều cho các giai đoạn này.
Với tộc sống lâu, một sự kiện có thể kéo dài hàng chục năm; hãy để thời gian cảm thấy dài.

=== CÁCH GAME VẬN HÀNH (để bạn viết cho khớp) ===
- Mỗi năm người chơi chọn một VIỆC CHÍNH: Rong chơi (chỉ tuổi thơ) · Học hành · Khổ luyện · Làm lụng (làm nghề) · Mạo hiểm · Giao du · An dưỡng.
  Việc chính quyết định loại sự kiện xảy ra và chỉ số nào tăng.
- 4 chỉ số: Sức mạnh, Trí tuệ, Nhanh nhẹn, May mắn (thường 1–15). 3 thanh: Sức khỏe, Hạnh phúc, Tài sản (0–100). Thêm Danh vọng.
- NGHỀ: chọn từ cuối tuổi thiếu niên. Mỗi nghề 5 bậc, thăng bậc bằng thử thách dựa vào chỉ số chính. Có thể mất nghề, đổi nghề.
- GUILD BÌNH MINH (VÀ ĐỘI RANGER ĐẠI NGÀN): F → E → D → C → B → A → S. Nhận nhiệm vụ gồm 1–5 CẢNH nối tiếp, mỗi cảnh 2–3 lựa chọn.
- TỔ ĐỘI: tối đa 3 đồng đội có tên, nghề, tính cách và độ thân thiết; có thể bị thương, chết, bỏ đi, phản bội, thành bạn đời.
- GIA ĐÌNH: cha mẹ (có thể sống, mất, bỏ đi), tỏ tình → hôn nhân → con cái.
- DẤU ẤN: lựa chọn để lại dấu ấn; nhiều năm sau, sự kiện khác chỉ xảy ra nếu có dấu ấn đó.
- Game đã có sẵn 96 sự kiện cũ cho tộc này (đời thường, ngẫu nhiên). Lần này bạn viết LỚP MỚI gắn với
  việc chính, nghề, nhiệm vụ, tổ đội, gia đình. Tránh lặp lại những ý quá quen.

=== THẾ GIỚI AETHELGARD ===
Lịch Kỷ Nguyên Khai Hoang. Tiền: Đồng Cẩm Thạch → Tinh Bạc → Huyết Kim → Lõi Mana.
Vùng đất: Đồng Bằng Thánh Quang (thủ đô Sanctus, Học viện Ma pháp Tháp Ngà; Con người, Dwarf),
Thảo Nguyên Gió Hú (Beastman, Con người, Orc), Đại Ngàn Lục Bảo (Elf, Cây Thế Giới Yggdrasil),
Dãy Núi Răng Cưa (Dwarf, Kobold; Lò Rèn Vĩnh Cửu), Đầm Lầy Tử Khí (Lizardman, Slime, Goblin),
Vực Thẳm Phân Tầng (Ma tộc, Imp, Vampire, Ghoul, Troll; Cửa Ngục Than Khóc), Đảo Tro Tàn (Rồng, Minotaur; Đỉnh Hỏa Ngục).
Tôn giáo: Giáo hội Thánh Quang (Nữ thần Lumina, căm ghét ma vật), Tự Nhiên Giáo (trung lập),
Hắc Nguyệt Hội (tà giáo thờ Vực Thẳm Cổ Thần, hiến tế).
Tổ chức: Guild Bình Minh (mạo hiểm giả), Học viện Ma pháp Tháp Ngà, Thánh Kỵ Sĩ Đoàn, Quân đoàn Ma Vương (của Ma Vương),
Thương hội Sói Bạc, Guild Sát thủ Umbra, Đấu trường Huyết Sa, Đội Ranger Đại Ngàn.
4 thời đại: Thời Bình · Chiến Tranh Tuyến Đầu · Kỷ Nguyên Tăm Tối (dịch bệnh, đói) · Ma Vương Giáng Thế.

=== PHONG CÁCH TÊN GỌI: KIỂU MANGA / LIGHT NOVEL DỊCH (BẮT BUỘC) ===
- Tên chủng tộc GIỮ NGUYÊN tiếng Anh: Human, Beastman, Dwarf, Elf, Demon, Goblin, Slime, Kobold, Lizardman,
  Vampire, Imp, Orc, Minotaur, Troll, Ghoul, Dragon, High Demon. Beastman ghi kèm dạng thú: "Beastman tộc Mèo".
  KHÔNG dịch thuần Việt kiểu "Yêu tinh xanh", "Người lùn", "Tiên tộc", "Chằn tinh", "Khổng lồ ngốc".
  Khi một tộc xuất hiện lần đầu trong đoạn mở đầu, kèm giải thích ngắn trong ngoặc, ví dụ:
  "Bạn là Gruum, thuộc chủng tộc Goblin (tiểu yêu da xanh sống theo bầy, yếu ớt nhưng ranh mãnh)."
- Nghề, chức vụ, cấp bậc, danh hiệu theo lối truyện isekai dịch:
  Hán Việt đã thành chuẩn: Kiếm Thánh, Hiền Giả, Dũng Giả, Ma Vương, Thánh Nữ, Đại Ma pháp sư, Mạo hiểm giả hạng S;
  hoặc tên class tiếng Anh: Assassin, Priest, Ranger, Berserker, Tamer, Necromancer, Dark Knight.
  Biến thể và tiến hóa của ma vật luôn bằng tiếng Anh: Hobgoblin, Goblin Lord, High Orc, Slime King, Ancient Dragon, Lich.
- Hệ thống gọi như manga: Guild, hạng F→S, Skill, tiến hóa, triệu hồi, Dungeon (hầm ngục).
- Tên tổ chức: Guild Bình Minh (Hội Mạo hiểm giả), Học viện Ma pháp Tháp Ngà, Thánh Kỵ Sĩ Đoàn, Quân đoàn Ma Vương,
  Thương hội Sói Bạc, Guild Sát thủ Umbra, Đấu trường Huyết Sa, Đội Ranger Đại Ngàn.
- Văn kể vẫn là tiếng Việt Epic RPG, ngôi thứ hai. Chỉ tên riêng và thuật ngữ mang màu manga.

=== GIỌNG VĂN: EPIC RPG ===
Sử thi, trang trọng, tự sự cổ điển, ngôi thứ hai ("bạn"). Mỗi đoạn 1–2 câu. Câu sau là một hình ảnh
hoặc chi tiết định mệnh. Được phép hài hước khô khan hoặc u tối khi hợp cảnh.
Ví dụ đạt: "Một kỵ sĩ quý tộc ném găng xuống chân bạn giữa quảng trường, chỉ vì bạn không cúi chào."
Ví dụ đạt: "{ally} quỳ bên bạn suốt đêm, đôi tay phát sáng ánh thánh quang. Sáng hôm sau, bạn mở mắt."
KHÔNG dùng tên, câu chữ hay tình huống của game, truyện, phim có thật.
Riêng tộc này: Thanh tao, u hoài, nhìn thế gian qua hàng thế kỷ. Bi kịch nằm ở chỗ những người bạn phàm trần lần lượt già đi và chết.

=== LỰA CHỌN PHẢI CÓ Ý NGHĨA ===
- Mỗi lựa chọn nên dựa vào MỘT chỉ số khác nhau, để người mạnh, người khôn, người nhanh, người may mắn
  đều có lối đi riêng.
- Có thể thêm một lựa chọn BỊ KHÓA nếu thiếu chỉ số hoặc dấu ấn (ví dụ "chỉ mở khi Trí tuệ từ 7").
  Người chơi vẫn thấy nó và biết mình thiếu gì.
- Luôn có ít nhất một lựa chọn an toàn hoặc hèn nhát nhưng có cái giá riêng.
- Độ khó dùng 4 mức: DỄ, VỪA, KHÓ, RẤT KHÓ.
- Hệ quả ghi rõ con số: Sức mạnh +1, Tài sản +10, Sức khỏe −20, Danh vọng +3,
  Thân thiết với {ally} +10, dấu ấn "ten_dau_an". Nếu chết thì ghi CHẾT và viết câu mô tả cái chết.
- Năm yên ả được game tự gộp lại. Vì vậy mỗi sự kiện phải ĐÁNG KỂ: có biến cố, có lựa chọn, hoặc một chi
  tiết khó quên. KHÔNG viết kiểu "một năm bình thường trôi qua".

=== TÊN GỌI TRONG CÂU CHỮ ===
{name} tên nhân vật · {father} cha · {mother} mẹ · {maker} kẻ tạo ra/chủ nhân (cho tộc không có cha mẹ)
{ally} một đồng đội · {spouse} bạn đời · {child} một đứa con.

=== MẪU TRÌNH BÀY (dùng đúng mẫu này cho mọi sự kiện) ===

### [MÃ] Tên ngắn
- **Khi nào:** giai đoạn · việc chính · nghề và bậc (nếu có) · điều kiện khác (chỉ số, dấu ấn, có đồng đội, cha/mẹ còn sống...)
- **Tình huống:** 1–2 câu.
- **A. "Nhãn lựa chọn"** — dựa vào [chỉ số], [độ khó]
  - Thành công: 1–2 câu. → hệ quả
  - Thất bại: 1–2 câu. → hệ quả
- **B. "Nhãn lựa chọn"** — (không tung xúc xắc) 1–2 câu. → hệ quả
- **C. "Nhãn lựa chọn"** — KHÓA nếu Trí tuệ dưới 7 — 1–2 câu. → hệ quả
- **Khoảnh khắc:** (tùy chọn) một dòng ngắn ghi vào tổng kết cuộc đời.

Sự kiện KHÔNG có lựa chọn thì chỉ cần: Khi nào, Tình huống, Hệ quả.

QUY ƯỚC BẮT BUỘC (để game đọc đúng):
- Dòng khóa luôn viết dạng điều kiện CẦN CÓ: "KHÓA: cần Trí tuệ 6", "KHÓA: cần dấu ấn "x" hoặc Trí tuệ 7".
  Không viết "KHÓA nếu ... từ ..." (dễ hiểu ngược).
- Sự kiện có lựa chọn phải có ÍT NHẤT 2 lựa chọn. Lựa chọn liều mạng luôn đi kèm một lựa chọn an toàn hoặc hèn nhát.
- Chỉ tung xúc xắc bằng: Sức mạnh, Trí tuệ, Nhanh nhẹn, May mắn hoặc Sức khỏe.
- Tài sản và Danh vọng tính trên thang 0–100: thưởng thường +5..+30, thưởng huyền thoại tối đa +100.
- Hệ quả đặc biệt dùng đúng chữ: "thu nhận {ally}", "mất {ally}", "có {spouse}", "có {child}", "mất {child}",
  "giáng chức về Bậc 1", "thăng bậc <tên bậc>", "TIẾN HÓA THÀNH <tên>", "CHẾT (lý do ngắn)".
- Mỗi kết quả trong một CẢNH của nhiệm vụ/cướp phá kết thúc bằng đúng một trong: (THẮNG NGAY ...), (THẤT BẠI NGAY ...),
  (Chuyển sang CẢNH n ...), (CHẾT, lý do). Không ghi gì nghĩa là đi tiếp sang cảnh kế.
MÃ viết thường, không dấu, bắt đầu bằng mã tộc, ví dụ elf_job_duel, elf_quest_ruins_2.

Hãy trả lời "Đã hiểu" và chờ tôi gửi từng phần.
```

---

## PHẦN 1 — Xuất thân và cha mẹ

```
PHẦN 1: Xuất thân và cha mẹ

Viết lại xuất thân, lần này kèm đầy đủ thông tin CHA MẸ.
Cách ra đời của tộc này: Sinh ra từ cha mẹ Elf. Elf sinh con rất hiếm; một đứa trẻ là sự kiện của cả cộng đồng. Cha mẹ sống hàng nghìn năm nên có thể đồng hành cả đời bạn, hoặc rời đi vì lý do riêng. Con lai với Con người (Half-Elf) bị cả hai bên xa lánh.

a) 8 xuất thân ĐÃ CÓ bên dưới: giữ tên và ý chính, bổ sung cha mẹ, anh chị em, gia cảnh.
   - Nụ Hoa Hoàng Tộc (dấu ấn: royal_blood)
   - Doanh Trại Tuần Lâm (dấu ấn: ranger_born)
   - Kẻ Lưu Đày Sanctus (dấu ấn: exiled)
   - Lá Vàng Rơi (dấu ấn: nature_child)
   - Kết Tinh Ma Thuật (dấu ấn: mana_anomaly)
   - Cô Nhi Chiến Hỏa (dấu ấn: war_orphan)
   - Hậu Duệ Thương Đoàn (dấu ấn: merchant_born)
   - Dấu Ấn Hắc Nguyệt (dấu ấn: dark_mark)
b) Viết thêm 2 xuất thân MỚI.

Mỗi xuất thân viết theo mẫu:

### [MÃ] Tên xuất thân — tỉ lệ gặp (phần trăm, cộng các xuất thân lại khoảng 100)
- **Đoạn mở đầu:** 2–3 câu kể lúc bạn ra đời.
- **Cha:** tên · tộc · nghề hoặc vai trò · tính cách · tình trạng lúc bạn ra đời (còn sống / đã mất / bỏ đi / không rõ là ai)
- **Mẹ:** như trên
- **Anh chị em:** số lượng và một chi tiết đáng nhớ (hoặc "không có")
- **Gia cảnh:** 1 câu (giàu nghèo, được yêu thương hay bị ruồng bỏ)
- **Ảnh hưởng:** chỉ số cộng/trừ, Tài sản, dấu ấn

c) 6 SỰ KIỆN VỀ CHA MẸ trải khắp cuộc đời, theo mẫu sự kiện. Ví dụ: {father} dạy bạn điều đầu tiên,
   {mother} lâm bệnh, cha mẹ phản đối nghề hay người bạn chọn, bạn gặp lại người cha đã bỏ đi,
   cha mẹ qua đời và bạn thừa kế (hoặc gánh nợ), bạn trở thành người chăm sóc cha mẹ già.
   Ghi rõ điều kiện (ví dụ "chỉ khi cha còn sống", "chỉ khi xuất thân mồ côi").
```

---

## PHẦN 2 — Nghề (đợt 1/2)

```
PHẦN 2: Nghề (đợt 1/2)

Tộc này có 7 nghề. Gợi ý (được đổi tên, gộp, thay hoặc thêm nếu bạn có ý hay hơn, miễn đủ 7):
Ranger / Cung thủ (Nhanh nhẹn) · Tinh linh sư / Spirit Caller (Trí tuệ) · Thảo dược sư (Trí tuệ) · Bard / Thi nhân (May mắn) · Hộ vệ Yggdrasil (Sức mạnh và Trí tuệ) · Thợ mộc Thánh Thụ (Nhanh nhẹn) · Sứ giả (Trí tuệ)

Trước tiên, liệt kê đủ 7 nghề bạn chọn (tên + chỉ số chính + 1 câu mô tả), đánh số 1 → 7.
Sau đó viết chi tiết nghề số 1 → 5.

Với MỖI nghề, viết:
1. Điều kiện vào nghề (chỉ số tối thiểu) và một lối vào phụ cho người có xuất thân đặc biệt.
2. Tên 5 bậc, từ thấp đến cao.
3. Câu mở đầu khi bước vào nghề.
4. 4 thử thách thăng bậc (bậc 1→2, 2→3, 3→4, 4→5), độ khó tăng dần.
5. 3 câu "năm yên ả" khi làm nghề nhiều năm không có biến cố.
6. 4 SỰ KIỆN NGHỀ theo mẫu: ít nhất 3 có lựa chọn; trải đều người mới, bậc giữa, bậc cao.
   Ít nhất 1 sự kiện có thể khiến mất nghề. Ít nhất 1 sự kiện chỉ xảy ra trong thời Chiến Tranh hoặc Ma Vương.
```

---

## PHẦN 3 — Nghề (đợt 2/2)

```
PHẦN 3: Nghề (đợt 2/2)

Viết chi tiết nghề số 6 → 7 trong danh sách bạn đã liệt kê.

Với MỖI nghề, viết:
1. Điều kiện vào nghề (chỉ số tối thiểu) và một lối vào phụ cho người có xuất thân đặc biệt.
2. Tên 5 bậc, từ thấp đến cao.
3. Câu mở đầu khi bước vào nghề.
4. 4 thử thách thăng bậc (bậc 1→2, 2→3, 3→4, 4→5), độ khó tăng dần.
5. 3 câu "năm yên ả" khi làm nghề nhiều năm không có biến cố.
6. 4 SỰ KIỆN NGHỀ theo mẫu: ít nhất 3 có lựa chọn; trải đều người mới, bậc giữa, bậc cao.
   Ít nhất 1 sự kiện có thể khiến mất nghề. Ít nhất 1 sự kiện chỉ xảy ra trong thời Chiến Tranh hoặc Ma Vương.
```

---

## PHẦN 4 — Tổ chức: Guild Bình Minh (và Đội Ranger Đại Ngàn)

```
PHẦN 4: Tổ chức: Guild Bình Minh (và Đội Ranger Đại Ngàn)

Ngoài nghề, tộc này có tổ chức riêng: Guild Bình Minh (và Đội Ranger Đại Ngàn), với F → E → D → C → B → A → S.
Đặt tên các bậc (nếu chưa có), mỗi bậc 1 câu khi được thăng lên. Viết 1 sự kiện gia nhập có lựa chọn và 1 sự kiện rời bỏ hoặc phản bội tổ chức.
```

---

## PHẦN 5 — Sự kiện theo việc chính (đợt 1/2)

```
PHẦN 5: Sự kiện theo việc chính (đợt 1/2)

Viết sự kiện theo VIỆC CHÍNH của năm. Mỗi việc chính dưới đây: 4 sự kiện (ít nhất một nửa có lựa chọn),
trải đều các giai đoạn đời mà việc đó có thể diễn ra, cộng thêm 3 câu "năm yên ả" cho mỗi giai đoạn phù hợp.
- Rong chơi
- Học hành
- Khổ luyện
- Làm lụng
```

---

## PHẦN 6 — Sự kiện theo việc chính (đợt 2/2)

```
PHẦN 6: Sự kiện theo việc chính (đợt 2/2)

Viết sự kiện theo VIỆC CHÍNH của năm. Mỗi việc chính dưới đây: 4 sự kiện (ít nhất một nửa có lựa chọn),
trải đều các giai đoạn đời mà việc đó có thể diễn ra, cộng thêm 3 câu "năm yên ả" cho mỗi giai đoạn phù hợp.
- Mạo hiểm
- Giao du
- An dưỡng
```

---

## PHẦN 7 — Nhiệm vụ nhỏ

```
PHẦN 7: Nhiệm vụ nhỏ

Nhiệm vụ của Guild Bình Minh (và Đội Ranger Đại Ngàn). Mỗi cái gồm: tên, hạng tối thiểu (F..S),
một gợi ý ngắn hiện trên bảng (ví dụ "Vừa. Hay có bẫy"), đoạn mở đầu, các CẢNH (mỗi cảnh viết theo mẫu sự kiện),
đoạn kết khi thành công, phần thưởng (Tài sản, Danh vọng, điểm thăng bậc) và khoảnh khắc.
Ghi rõ lựa chọn nào khiến THẤT BẠI NGAY, THẮNG NGAY, hoặc gây CHẾT.

Viết 4 nhiệm vụ NHỎ lặp lại được, 1–2 cảnh, rải đều từ bậc thấp đến bậc giữa.
```

---

## PHẦN 8 — Nhiệm vụ cốt truyện

```
PHẦN 8: Nhiệm vụ cốt truyện

Tộc này có 4 nhiệm vụ CỐT TRUYỆN chỉ làm một lần, mỗi cái 3–5 cảnh, độ khó tăng dần từ bậc thấp đến bậc cao nhất.
Cái cuối cùng phải mang tầm vóc huyền thoại. Ít nhất 2 cái để lại DẤU ẤN mà phần "Chuỗi hệ quả" sẽ dùng lại.
Trước tiên liệt kê tên + bậc của cả 4 cái. Viết chi tiết số 1 → 4, cùng mẫu như phần nhiệm vụ nhỏ.

Viết thêm 2 nhiệm vụ chỉ xuất hiện trong một thời đại cụ thể (Chiến Tranh Tuyến Đầu, Kỷ Nguyên Tăm Tối hoặc Ma Vương Giáng Thế).
```

---

## PHẦN 9 — Tổ đội

```
PHẦN 9: Tổ đội

Sự kiện về tổ đội. Gọi đồng đội là {ally}. Mỗi đồng đội có một tính cách:
Dũng cảm, Trung thành, Tham lam, Nhút nhát, Vui tính, Lạnh lùng.
a) Với mỗi tính cách: 1 sự kiện riêng, tính cách phải thể hiện rõ.
b) 4 sự kiện chung: cãi vã, cứu nhau, chia chiến lợi phẩm, một người muốn rời đi, bí mật quá khứ bị lộ...
c) 2 sự kiện đồng đội thân thiết trở thành người yêu.
d) 3 câu khi đồng đội CHẾT, 3 câu khi BỊ THƯƠNG, 3 câu khi BỎ ĐI hoặc PHẢN BỘI.
```

---

## PHẦN 10 — Tình duyên, gia đình, tuổi già

```
PHẦN 10: Tình duyên, gia đình, tuổi già

a) 3 cảnh gặp gỡ dẫn đến tỏ tình (lễ hội, chợ, chiến trường, đền thờ...), mỗi cảnh có câu đồng ý và câu từ chối.
   Ghi rõ người kia thuộc tộc nào; ít nhất 1 mối tình khác tộc.
b) 5 sự kiện đời sống vợ chồng: hạnh phúc, cãi vã, ngoại tình, {spouse} lâm bệnh, {spouse} qua đời...
c) 5 sự kiện về con cái {child}: con tập đi, con bỏ nhà đi mạo hiểm, con nối nghề, con phản bội, con đưa cháu về...
d) 4 sự kiện tuổi già: truyền nghề, nhìn lại đời, kẻ thù cũ tìm đến, lập di chúc...
```

---

## PHẦN 11 — Chuỗi hệ quả

```
PHẦN 11: Chuỗi hệ quả

Tộc này có 4 CHUỖI HỆ QUẢ, mỗi chuỗi 2–3 sự kiện cách nhau nhiều năm.
- Sự kiện đầu để lại một DẤU ẤN. Sự kiện sau CHỈ xảy ra nếu có dấu ấn đó, và kết quả khác nhau tùy lựa chọn năm xưa.
- Ít nhất 2 chuỗi dùng dấu ấn từ nhiệm vụ cốt truyện; ít nhất 1 chuỗi liên quan đến cha mẹ.
- Ghi tên dấu ấn rõ ràng, ví dụ dấu ấn "tha_ten_trom".
Viết chuỗi số 1 → 4.
```
